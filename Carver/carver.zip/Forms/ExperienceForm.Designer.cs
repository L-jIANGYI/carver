﻿namespace Carver.Forms
{
    partial class ExperienceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(36, 38);
            label1.Name = "label1";
            label1.Size = new Size(403, 20);
            label1.TabIndex = 0;
            label1.Text = " Het rijden in een Carver voldoet aan mijn verwachting";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(36, 128);
            label2.Name = "label2";
            label2.Size = new Size(311, 20);
            label2.TabIndex = 1;
            label2.Text = "De prijsstelling van de Carver is naar wens";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(36, 217);
            label3.Name = "label3";
            label3.Size = new Size(361, 20);
            label3.TabIndex = 2;
            label3.Text = "De extra opties op een Carver vind ik toereikend";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(36, 308);
            label4.Name = "label4";
            label4.Size = new Size(316, 20);
            label4.TabIndex = 3;
            label4.Text = "Ik ga snel over tot aanschaf van een Carver";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(58, 83);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(135, 24);
            radioButton1.TabIndex = 4;
            radioButton1.TabStop = true;
            radioButton1.Text = "Niet mee eens";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(221, 83);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(92, 24);
            radioButton2.TabIndex = 5;
            radioButton2.TabStop = true;
            radioButton2.Text = "Neutraal";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(378, 83);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(101, 24);
            radioButton3.TabIndex = 6;
            radioButton3.TabStop = true;
            radioButton3.Text = "Mee eens";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // ExperienceForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(radioButton3);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "ExperienceForm";
            Text = "ExperienceForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
    }
}